"use strict";
//# sourceMappingURL=pokemon.js.map