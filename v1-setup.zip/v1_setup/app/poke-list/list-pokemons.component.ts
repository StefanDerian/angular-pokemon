import { Component, OnInit } from '@angular/core';
import { Pokemon } from '../shared/pokemon';
import { PokemonService } from '../shared/pokemon.service';

@Component({
  moduleId: module.id,
  templateUrl: 'list-pokemons.template.html'
})

export class ListPokemonsComponent {

}