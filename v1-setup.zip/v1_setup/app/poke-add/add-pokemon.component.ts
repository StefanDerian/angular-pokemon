import { Component, OnInit } from '@angular/core';
import { Pokemon } from '../shared/pokemon';
import { PokemonService } from '../shared/pokemon.service';

@Component({
  moduleId: module.id,
  templateUrl: 'add-pokemon.template.html'
})

export class AddPokemonComponent {

}